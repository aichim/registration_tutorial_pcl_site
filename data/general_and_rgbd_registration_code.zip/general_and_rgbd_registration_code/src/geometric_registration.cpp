#include "impl/geometric_registration.hpp"
#include "pcl/point_types.h"
#include "pcl/impl/instantiate.hpp"

PCL_INSTANTIATE_GeometricRegistration(pcl::PointXYZRGBNormal)
PCL_INSTANTIATE_GeometricRegistration(pcl::PointNormal)

