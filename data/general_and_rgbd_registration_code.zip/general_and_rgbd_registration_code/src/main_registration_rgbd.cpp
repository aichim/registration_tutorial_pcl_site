#include <pcl/console/parse.h>
#include <pcl/console/print.h>

#include <pcl/io/pcd_io.h>
#include <pcl/features/normal_3d.h>
#include <pcl/features/integral_image_normal.h>

#include "geometric_registration.h"


using namespace pcl;

typedef pcl::PointXYZ PointTL;
typedef pcl::PointNormal PointTP;

void
getFilesFromDirectory (const std::string path_dir,
                       const std::string extension,
                       std::vector<std::string> &files)
{
  if (path_dir != "" && boost::filesystem::exists (path_dir))
  {
    boost::filesystem::directory_iterator end_itr;
    for (boost::filesystem::directory_iterator itr (path_dir); itr != end_itr; ++itr)
      if (!is_directory (itr->status ()) &&
          boost::algorithm::to_upper_copy (boost::filesystem::extension (itr->path ())) == boost::algorithm::to_upper_copy (extension))
      {
        files.push_back (itr->path ().string ());
      }
  }
  sort (files.begin (), files.end ());
}




int
main (int argc,
      char **argv)
{
  /// Read in the command line parameters
  std::string input_dir = "";
  console::parse_argument (argc, argv, "-input_dir", input_dir);

  if (input_dir == "")
  {
    /// TODO print full help line in a separate method
    PCL_ERROR ("Syntax error: no input directory specified.\n");
    return (-1);
  }

  /// Get the list of files
  std::vector<std::string> pcd_files;
  getFilesFromDirectory (input_dir, ".PCD", pcd_files);

  std::vector<std::string> pcd_files_aux;
  for (size_t i = 0; i < pcd_files.size (); i += 2)
    pcd_files_aux.push_back (pcd_files [i]);
  pcd_files = pcd_files_aux;



  af::GeometricRegistration<PointTP> registration;
  registration.setEnableVisualization (true);
  Eigen::Matrix4f transf_cummulated (Eigen::Matrix4f::Identity ());
  
  pcl::PointCloud<PointTP>::Ptr prev_cloud;
  for (int frame_id = 0; frame_id < pcd_files.size (); ++frame_id)
  {
    std::cerr << "loading: " << pcd_files[frame_id] << std::endl;
    
    pcl::PointCloud<PointTL>::Ptr cloud (new pcl::PointCloud<PointTL> ());
    pcl::io::loadPCDFile (pcd_files[frame_id], *cloud);

    pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud_original (new pcl::PointCloud<pcl::PointXYZRGB> ());
    pcl::io::loadPCDFile (pcd_files[frame_id], *cloud_original);
    
    std::cerr << "  number of points: " << cloud->size () << std::endl;

    // compute normals
    pcl::PointCloud<pcl::Normal>::Ptr normals (new pcl::PointCloud<pcl::Normal>);

//    pcl::NormalEstimation<pcl::PointXYZ, pcl::Normal> ne;
    pcl::IntegralImageNormalEstimation<pcl::PointXYZ, pcl::Normal> ne;
    ne.setRadiusSearch (0.03);
    ne.setKSearch (0);
    ne.setInputCloud (cloud);

    pcl::search::KdTree<pcl::PointXYZ>::Ptr tree (new pcl::search::KdTree<pcl::PointXYZ> ());
    ne.setSearchMethod (tree);

    ne.setRadiusSearch (0.03);
    ne.compute (*normals);

    pcl::PointCloud<PointTP>::Ptr cloud_with_normals (new PointCloud<PointTP> ());
    for (int point_id = 0; point_id < cloud->size (); ++point_id)
    {
      PointTP p;
      p.x = cloud->points[point_id].x;
      p.y = cloud->points[point_id].y;
      p.z = cloud->points[point_id].z;
      p.normal_x = normals->points[point_id].normal_x;
      p.normal_y = normals->points[point_id].normal_y;
      p.normal_z = normals->points[point_id].normal_z;

      cloud_with_normals->push_back (p);
    }
    cloud_with_normals->width = cloud->width;
    cloud_with_normals->height = cloud->height;
    cloud_with_normals->is_dense = cloud->is_dense;

    std::stringstream cloud_name;
    std::stringstream cloud_with_normals_name;
    cloud_name << frame_id << ".pcd";
    cloud_with_normals_name << frame_id << "n.pcd";

    pcl::io::savePCDFileBinaryCompressed (cloud_name.str ().c_str (), *cloud);
    pcl::io::savePCDFileBinaryCompressed (cloud_with_normals_name.str ().c_str (), *cloud_with_normals);

    // register to previous frame

    if (frame_id > 0)
    {
      pcl::PointCloud<PointTP>::Ptr cloud_aligned (new pcl::PointCloud<PointTP> ());

      pcl::IndicesPtr indices (new std::vector<int> ());
      pcl::IndicesPtr prev_indices (new std::vector<int> ());

      for (int point_id = 0; point_id < prev_cloud->points.size (); ++point_id)
      {
        if (pcl::isFinite (prev_cloud->points[point_id]))
          prev_indices->push_back (point_id);
      }

      for (int point_id = 0; point_id < cloud->points.size (); ++point_id)
      {
        if (pcl::isFinite (cloud->points[point_id]))
          indices->push_back (point_id);
      }

      std::cerr << "prev_cloud: " << prev_cloud->size () << std::endl;
      std::cerr << "cloud: " << cloud->size () << std::endl;

      std::cerr << "prev_indices: " << prev_indices->size () << std::endl;
      std::cerr << "indices: " << indices->size () << std::endl;

      Eigen::Matrix4f final_transform;
      float alginment_score;
      Eigen::Matrix<double, 6, 6> covariance_matrix;

      std::cerr << "align cloud..." << std::endl;
      registration.align (
        cloud_with_normals, 
        prev_cloud, 
        indices, 
        prev_indices, 
        cloud_aligned, 
        final_transform, 
        alginment_score, 
        covariance_matrix);

      std::cerr << final_transform << std::endl;
      transf_cummulated = transf_cummulated * final_transform;

      std::stringstream cloud_aligned_name;
      cloud_aligned_name << frame_id << "a.pcd";

      pcl::PointCloud<pcl::PointXYZRGB> cloud_aligned_global;
      pcl::transformPointCloud (*cloud_original, cloud_aligned_global, transf_cummulated);
      pcl::io::savePCDFileBinaryCompressed (cloud_aligned_name.str ().c_str (), cloud_aligned_global);
    }

    prev_cloud.swap (cloud_with_normals);
  }




  return (0);
}
