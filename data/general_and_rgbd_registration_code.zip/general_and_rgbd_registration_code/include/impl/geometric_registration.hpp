#pragma once

#include "geometric_registration.h"
#include <pcl/console/time.h>
#include <pcl/common/transforms.h>
#include <pcl/common/pca.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/normal_space.h>
#include <pcl/filters/covariance_sampling.h>
#include <pcl/registration/correspondence_rejection_median_distance.h>

// #include <pcl/registration/transformation_estimation_svd.h>
// #include <pcl/registration/transformation_estimation_point_to_plane_lls.h>
// #include <pcl/registration/transformation_estimation_point_to_plane_lls_weighted.h>
#include <pcl/registration/transformation_estimation_point_to_plane_weighted.h>
// #include <pcl/registration/transformation_estimation_point_to_plane.h>
// #include <pcl/registration/transformation_estimation_lm.h>
// #include <pcl/registration/transformation_estimation_2D.h>
#include <pcl/registration/warp_point_rigid_3d.h>
#include <pcl/registration/correspondence_rejection_organized_boundary.h>


#include <pcl/io/pcd_io.h>

#define TIMINGS 0

template <typename PointT>
af::GeometricRegistration<PointT>::GeometricRegistration ()
  : sigma_z_min_ (0.0012f)
  , enable_visualization_ (true)
  , min_num_correspondences_ (3)
  , correspondence_rejection_normal_angle_threshold_ (cos (30. * M_PI / 180.))
  , correspondence_estimation_closest_point_distance_threshold_ (0.09)
  , max_num_iterations_projection_ (30)
{
  correspondence_estimation_projection_.reset (new pcl::registration::CorrespondenceEstimationOrganizedProjection<PointT, PointT> ());
   correspondence_estimation_closest_point_.reset (new pcl::registration::CorrespondenceEstimation<PointT, PointT> ());
  correspondence_rejection_normals_.reset (new pcl::registration::CorrespondenceRejectorSurfaceNormal ());
  // correspondence_rejection_sac_.reset (new pcl::registration::CorrespondenceRejectorSampleConsensus<PointT> ());
}

template <typename PointT> void
af::GeometricRegistration<PointT>::getCorrespondencesProjection (CloudConstPtr cloud_src,
                                                                 CloudConstPtr cloud_tgt,
                                                                 pcl::IndicesPtr indices_non_nan_src,
                                                                 pcl::IndicesPtr indices_non_nan_tgt,
                                                                 pcl::Correspondences &corresps)
{
  correspondence_estimation_projection_->setFocalLengths (525. / (640. / cloud_src->width), 525. / (640. / cloud_src->width));
  correspondence_estimation_projection_->setCameraCenters (cloud_src->width / 2, cloud_src->height / 2);

  correspondence_estimation_projection_->setInputSource (cloud_src);
  correspondence_estimation_projection_->setIndicesSource (indices_non_nan_src);
  correspondence_estimation_projection_->setInputTarget (cloud_tgt);
  correspondence_estimation_projection_->setIndicesTarget (indices_non_nan_tgt);

  //  corresp_estimation.determineReciprocalCorrespondences (correspondences, corresp_estimation_threshold_);
  correspondence_estimation_projection_->determineCorrespondences (corresps, correspondence_estimation_projection_distance_threshold_);
}


 template <typename PointT> void
 af::GeometricRegistration<PointT>::getCorrespondencesClosestPoint (CloudConstPtr cloud_src,
                                                                    CloudConstPtr cloud_tgt,
                                                                    pcl::IndicesPtr indices_non_nan_src,
                                                                    pcl::IndicesPtr indices_non_nan_tgt,
                                                                    pcl::Correspondences &corresps)
 {
   correspondence_estimation_closest_point_->setInputSource (cloud_src);
   correspondence_estimation_closest_point_->setIndicesSource (indices_non_nan_src);
   correspondence_estimation_closest_point_->setInputTarget (cloud_tgt);
   correspondence_estimation_closest_point_->setIndicesTarget (indices_non_nan_tgt);

   //  corresp_estimation.determineReciprocalCorrespondences (correspondences, corresp_estimation_threshold_);
   correspondence_estimation_closest_point_->determineCorrespondences (corresps, correspondence_estimation_closest_point_distance_threshold_);
 }


template <typename PointT> void
af::GeometricRegistration<PointT>::filterCorrespondences (pcl::CorrespondencesPtr &corresps_in,
                                                          CloudConstPtr cloud_src,
                                                          CloudConstPtr cloud_tgt,
                                                          pcl::Correspondences &corresps_filtered)
{
  pcl::registration::CorrespondenceRejectorMedianDistance rejector_median_dist;
  rejector_median_dist.setInputSource<PointT> (cloud_src);
  rejector_median_dist.setInputTarget<PointT> (cloud_tgt);
  rejector_median_dist.setInputCorrespondences (corresps_in);
  rejector_median_dist.setMedianFactor (4.5);

  pcl::CorrespondencesPtr filtered_median_correspondences (new pcl::Correspondences ());
  rejector_median_dist.getCorrespondences (*filtered_median_correspondences);

  PCL_INFO ("-------- Median correspondence rejection: before %zu --- after %zu\n",
            corresps_in->size (), filtered_median_correspondences->size ());

  // pcl::registration::CorrespondenceRejectionOrganizedBoundary rejector_boundary;
  // rejector_boundary.setInputSource<PointT> (cloud_src);
  // rejector_boundary.setInputTarget<PointT> (cloud_tgt);
  // rejector_boundary.setInputCorrespondences (filtered_median_correspondences);
  pcl::CorrespondencesPtr filtered_boundary_correspondences (new pcl::Correspondences ());
  // // rejector_boundary.getCorrespondences (*filtered_boundary_correspondences);
  *filtered_boundary_correspondences = *filtered_median_correspondences;

  PCL_INFO ("-------- Boundary points rejection: before %zu --- after %zu\n",
            filtered_median_correspondences->size (), filtered_boundary_correspondences->size ());

  correspondence_rejection_normals_->initializeDataContainer<PointT, PointT> ();
  correspondence_rejection_normals_->setInputSource<PointT> (cloud_src);
  correspondence_rejection_normals_->setInputNormals<PointT, PointT> (cloud_src);
  correspondence_rejection_normals_->setInputTarget<PointT> (cloud_tgt);
  correspondence_rejection_normals_->setTargetNormals<PointT, PointT> (cloud_tgt);
  correspondence_rejection_normals_->setThreshold (correspondence_rejection_normal_angle_threshold_);
  correspondence_rejection_normals_->setInputCorrespondences (filtered_boundary_correspondences);
  pcl::CorrespondencesPtr filtered_normals_correspondences (new pcl::Correspondences ());
  correspondence_rejection_normals_->getCorrespondences (*filtered_normals_correspondences);


  // correspondence_rejection_sac_->setInputSource (cloud_src);
  // correspondence_rejection_sac_->setInputTarget (cloud_tgt);
  // correspondence_rejection_sac_->setRefineModel (true);
  // correspondence_rejection_sac_->setMaximumIterations (std::numeric_limits<int>::max ());
  // correspondence_rejection_sac_->setInlierThreshold (correspondence_rejection_sac_distance_threshold_);
  // correspondence_rejection_sac_->setInputCorrespondences (filtered_normals_correspondences);
  // correspondence_rejection_sac_->getCorrespondences (corresps_filtered);

  corresps_filtered = *filtered_normals_correspondences;

  PCL_INFO ("---- Correspondence rejection: initial: %d, after normal-based rejection %d, after SAC: %d\n",
            corresps_in->size (), filtered_normals_correspondences->size (), corresps_filtered.size ());
}



template <typename PointT> bool
af::GeometricRegistration<PointT>::align (CloudConstPtr cloud_src,
                                          CloudConstPtr cloud_tgt,
                                          pcl::IndicesPtr indices_non_nan_src,
                                          pcl::IndicesPtr indices_non_nan_tgt,
                                          CloudPtr cloud_src_non_nan_aligned,
                                          Eigen::Matrix4f &final_transform,
                                          float &alignment_score,
                                          Eigen::Matrix<double, 6, 6> &covariance_matrix,
                                          const Eigen::Matrix4f &initial_transform)
{
  if (enable_visualization_ && !visualizer_)
  {
    visualizer_.reset (new pcl::visualization::PCLVisualizer ("Geometric Registration Visualization"));
    visualizer_->setBackgroundColor (255., 255., 255.);
  }

  pcl::console::TicToc operation_timer;
  double duration;

  final_transform = initial_transform;

  alignment_score = 0.0f;
  pcl::CorrespondencesPtr correspondences (new pcl::Correspondences ());
  pcl::CorrespondencesPtr filtered_correspondences (new pcl::Correspondences ());


  /// TODO try custom parameters for the convergence criteria
  int iteration = 0;
  Eigen::Matrix4d transform = Eigen::Matrix4d::Identity ();

  pcl::registration::DefaultConvergenceCriteria<double> convergence_criteria (iteration, transform, *correspondences);
  convergence_criteria.setMaximumIterations (max_num_iterations_projection_);
  convergence_criteria.setMaximumIterationsSimilarTransforms (5);
  //  convergence_criteria.setTranslationThreshold (0.0005);
  //  convergence_criteria.setRotationThreshold (cos (0.5 * M_PI / 180.0));
  convergence_criteria.setRelativeMSE (0.005);

  //  pcl::registration::TransformationEstimationSVD<PointT, PointT, float> te;
  //      registration::TransformationEstimationPointToPlaneLLS<PointNT, PointNT, float> te;
//  pcl::registration::TransformationEstimationPointToPlaneLLSWeighted<PointT, PointT, float> te;
  //  pcl::registration::TransformationEstimationLM<PointT, PointT, double> te;
//    pcl::registration::TransformationEstimationPointToPlane<PointT, PointT, double> te;
  pcl::registration::TransformationEstimationPointToPlaneWeighted<PointT, PointT, double> te;

  pcl::console::TicToc icp_timer;
  icp_timer.tic ();

  /// Now a 2nd series with closest-point correspondence estimation
  iteration = 0;

  convergence_criteria.setMaximumIterations (max_num_iterations_projection_);

  icp_timer.tic ();

  pcl::ExtractIndices<PointT> extract_indices;
  extract_indices.setInputCloud (cloud_src);
  extract_indices.setIndices (indices_non_nan_src);
   CloudPtr cloud_src_non_nan (new Cloud ());
  extract_indices.filter (*cloud_src_non_nan);

  extract_indices.setInputCloud (cloud_tgt);
  extract_indices.setIndices (indices_non_nan_tgt);
  CloudPtr cloud_tgt_non_nan (new Cloud ());
  extract_indices.filter (*cloud_tgt_non_nan);

  pcl::NormalSpaceSampling<PointT, PointT> normal_space_sampling;
  normal_space_sampling.setInputCloud (cloud_src_non_nan);
  normal_space_sampling.setNormals (cloud_src_non_nan);
  normal_space_sampling.setBins (16, 16, 16);
  normal_space_sampling.setSample (45000);
  pcl::IndicesPtr indices_src_normal_sampled (new std::vector<int> ());
  normal_space_sampling.filter (*indices_src_normal_sampled);

  std::vector<bool> indices_taken (cloud_src_non_nan->size (), false);
  for (size_t i = 0; i < indices_src_normal_sampled->size (); ++i)
    indices_taken[i] = true;
  pcl::IndicesPtr indices_src_non_normal_sampled (new std::vector<int> ());
  for (size_t i = 0; i < indices_taken.size (); ++i)
    if (!indices_taken[i])
      indices_src_non_normal_sampled->push_back (i);


  // pcl::CovarianceSampling<PointT, PointT> covariance_based_sampling;
  // covariance_based_sampling.setInputCloud (cloud_src_non_nan_aligned);
  // covariance_based_sampling.setIndices (indices_src_non_normal_sampled);
  // covariance_based_sampling.setNormals (cloud_src_non_nan_aligned);
  // covariance_based_sampling.setNumberOfSamples (2000);
  // pcl::IndicesPtr indices_src_covariance_sampled (new std::vector<int> ());
  // covariance_based_sampling.filter (*indices_src_covariance_sampled);

  pcl::IndicesPtr indices_src_sampled (new std::vector<int> ());
  *indices_src_sampled = *indices_src_normal_sampled;
  // indices_src_sampled->insert (indices_src_sampled->end (),
                               // indices_src_covariance_sampled->begin (), indices_src_covariance_sampled->end ());


  pcl::IndicesPtr indices_tgt_sampled (new std::vector<int> ());
  indices_tgt_sampled->resize (cloud_tgt_non_nan->size ());
  for (size_t i = 0; i < indices_tgt_sampled->size (); ++i)
    (*indices_tgt_sampled)[i] = i;


  if (indices_src_sampled->size () < min_num_correspondences_ ||
      indices_tgt_sampled->size () < min_num_correspondences_)
  {
    PCL_ERROR ("Not enough points in clouds even before computing the correspondences.\n");
    return (false);
  }

  extract_indices.setInputCloud (cloud_src_non_nan);
  extract_indices.setIndices (indices_src_sampled);
  CloudPtr cloud_src_sampled (new Cloud ());
  extract_indices.filter (*cloud_src_sampled);

  extract_indices.setInputCloud (cloud_tgt_non_nan);
  extract_indices.setIndices (indices_tgt_sampled);
  CloudPtr cloud_tgt_sampled (new Cloud ());
  extract_indices.filter (*cloud_tgt_sampled);


  PCL_INFO ("Before normal space sampling %d ---> after %d\n", cloud_src_non_nan_aligned->size (), indices_src_sampled->size ());

  do
  {
    pcl::transformPointCloudWithNormals (*cloud_src_non_nan, *cloud_src_non_nan_aligned, final_transform);
//    pcl::transformPointCloudWithNormals (*cloud_src_aligned, *cloud_src_aligned, final_transform);
    operation_timer.tic ();

//    getCorrespondencesProjection (
    getCorrespondencesClosestPoint (
          cloud_src_non_nan_aligned,
                                  cloud_tgt_non_nan,
                                  indices_src_sampled,
                                  indices_tgt_sampled,
                                  *correspondences);
    duration = operation_timer.toc ();
    PCL_INFO ("Found initial set of correspondences (closest point): %ld\n", correspondences->size ());
#if TIMINGS
    PCL_INFO ("[TIMINGS] getCorrespondencesClosestPoint () -> %f ms\n", duration);
#endif



    /// 3b) Reject outlier correspondences
//    pcl::CorrespondencesPtr filtered_correspondences (new pcl::Correspondences ());
    operation_timer.tic ();
    filterCorrespondences (correspondences,
                           cloud_src_non_nan_aligned,
                           cloud_tgt_non_nan,
                           *filtered_correspondences);

    duration = operation_timer.toc ();
#if TIMINGS
    PCL_INFO ("[TIMINGS] filterCorrespondences () -> %f ms\n", duration);
#endif


    if (filtered_correspondences->size () < min_num_correspondences_)
    {
      PCL_ERROR ("Found less correspondences than the minimum desired number: %d vs %d\n",
                 filtered_correspondences->size (), min_num_correspondences_);
      return (false);
    }

    /// Re-weight correspondences
    std::vector<double> correspondence_weights (filtered_correspondences->size ());
    for (size_t i = 0; i < filtered_correspondences->size (); ++i)
    {
      float depth = cloud_tgt_non_nan->points[(*filtered_correspondences)[i].index_match].z;
      /// TODO add the angle, does not influence the results too much
      float sigma_z = 0.0012f + 0.0019f * (depth - 0.4f) * (depth - 0.4f);
      (*filtered_correspondences)[i].weight = sigma_z_min_ / sigma_z;
      correspondence_weights[i] = (*filtered_correspondences)[i].weight;
    }



    if (enable_visualization_)
    {
      CloudPtr cloud_src_sampled_aligned (new Cloud ());
      pcl::transformPointCloudWithNormals (*cloud_src_sampled, *cloud_src_sampled_aligned, final_transform);

      pcl::visualization::PointCloudColorHandlerCustom<PointT> color_src (cloud_src_sampled_aligned, 0., 255, 0.);
      if (!visualizer_->updatePointCloud<PointT> (cloud_src_sampled_aligned, color_src, "cloud_src"))
        visualizer_->addPointCloud<PointT> (cloud_src_sampled_aligned, color_src, "cloud_src");
      pcl::visualization::PointCloudColorHandlerCustom<PointT> color_tgt (cloud_tgt_sampled, 0, 20, 100);
      if (!visualizer_->updatePointCloud<PointT> (cloud_tgt_sampled, color_tgt, "cloud_tgt"))
        visualizer_->addPointCloud<PointT> (cloud_tgt_sampled, color_tgt, "cloud_tgt");

      visualizer_->removeCorrespondences ("correspondences");
      visualizer_->addCorrespondences<PointT> (cloud_src_non_nan_aligned, cloud_tgt_non_nan, *filtered_correspondences, 1, "correspondences");
      PCL_INFO ("Showing correspondences - press q to continue\n");
      visualizer_->spin ();
    }

    /// Compute transform
    operation_timer.tic ();
    te.setWeights (correspondence_weights);
    te.estimateRigidTransformation (*cloud_src_non_nan_aligned, *cloud_tgt_non_nan, *filtered_correspondences, transform);
    duration = operation_timer.toc ();
#if TIMINGS
    PCL_INFO ("[TIMINGS] estimateRigidTransformation () -> %f ms\n", duration);
#endif


    /// Update variables
    final_transform = transform.cast<float> () * final_transform;
    alignment_score = static_cast<float> (filtered_correspondences->size ()) / static_cast<float> (indices_non_nan_src->size ());
    iteration ++;
  } while (!convergence_criteria.hasConverged ());
  duration = icp_timer.toc ();
#if TIMINGS
  PCL_INFO ("[TIMINGS] Second set of ICP -> %f ms\n", duration);
#endif


  /// If we stopped because we reached the maximum number of iterations, then consider the alignment to be wrong
  if (iteration == max_num_iterations_projection_)
  {
    PCL_ERROR ("Did not converge ...\n");
    return false;
  }

  PCL_INFO ("Converged after %d iterations with fitness score %f\n", iteration, alignment_score);

  transformPointCloudWithNormals (*cloud_src_non_nan, *cloud_src_non_nan_aligned, final_transform);
  alignment_score = correspondences->size ();


  *cloud_src_non_nan_aligned = *cloud_src_sampled;

  return (true);
}


#define PCL_INSTANTIATE_GeometricRegistration(T) template class PCL_EXPORTS af::GeometricRegistration<T>;
