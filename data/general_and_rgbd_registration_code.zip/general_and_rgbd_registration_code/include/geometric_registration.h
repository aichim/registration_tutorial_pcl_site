#pragma once

#include <pcl/registration/correspondence_rejection_sample_consensus.h>


#include <pcl/filters/passthrough.h>
#include <pcl/registration/correspondence_estimation_normal_shooting.h>
#include <pcl/registration/correspondence_estimation_organized_projection.h>
#include <pcl/registration/correspondence_rejection_surface_normal.h>
#include <pcl/filters/filter_indices.h>
#include <pcl/registration/default_convergence_criteria.h>


#include <pcl/visualization/pcl_visualizer.h>


namespace af
{

  class MyConvergenceCriteria : public pcl::registration::DefaultConvergenceCriteria<float>
  {
      MyConvergenceCriteria (const int &iterations, const Eigen::Matrix4f &transform, const pcl::Correspondences &correspondences)
        : pcl::registration::DefaultConvergenceCriteria<float> (iterations, transform, correspondences)
      {
      }
  };

  template <typename PointT>
  class GeometricRegistration
  {
    public:
      typedef pcl::PointCloud<PointT> Cloud;
      typedef typename Cloud::Ptr CloudPtr;
      typedef typename Cloud::ConstPtr CloudConstPtr;

      GeometricRegistration ();

      inline void
      setCorrespondenceEstimationProjectionDistanceThreshold (float threshold)
      { correspondence_estimation_projection_distance_threshold_ = threshold; }

//      inline void
//      setCorrespondenceEstimationClosestPointDistanceThreshold (float threshold)
//      { correspondence_estimation_closest_point_distance_threshold_ = threshold; }

      inline void
      setCorrespondenceRejectionNormalAngleThreshold (float threshold)
      { correspondence_rejection_normal_angle_threshold_ = threshold; }

      // inline void
      // setCorrespondenceRejectionSACDistanceThreshold (float threshold)
      // { correspondence_rejection_sac_distance_threshold_ = threshold; }

      inline void
      setMaxNumIterationsProjection (int num_iterations)
      { max_num_iterations_projection_ = num_iterations; }

      // inline void
      // setMaxNumIterationsClosestPoint (int num_iterations)
      // { max_num_iterations_closest_point_ = num_iterations; }

      inline void
      setMinNumCorrespondences (int num_correspondences)
      { min_num_correspondences_ = num_correspondences; }



      inline void
      setEnableVisualization (bool enable_visualization)
      { enable_visualization_ = enable_visualization; }

      bool
      align (CloudConstPtr cloud_src,
             CloudConstPtr cloud_tgt,
             pcl::IndicesPtr indices_non_nan_src,
             pcl::IndicesPtr indices_non_nan_tgt,
             CloudPtr cloud_src_aligned,
             Eigen::Matrix4f &final_transform,
             float &alignment_score,
             Eigen::Matrix<double, 6, 6> &covariance_matrix,
             const Eigen::Matrix4f &initial_transform = Eigen::Matrix4f::Identity ());

      void
      getCorrespondencesProjection (CloudConstPtr cloud_src,
                                    CloudConstPtr cloud_tgt,
                                    pcl::IndicesPtr indides_non_nan_src,
                                    pcl::IndicesPtr indices_non_nan_tgt,
                                    pcl::Correspondences &corresps);

      void
      getCorrespondencesClosestPoint (CloudConstPtr cloud_src,
                                      CloudConstPtr cloud_tgt,
                                      pcl::IndicesPtr indides_non_nan_src,
                                      pcl::IndicesPtr indices_non_nan_tgt,
                                      pcl::Correspondences &corresps);

      void
      filterCorrespondences (pcl::CorrespondencesPtr &corresps_in,
                             CloudConstPtr cloud_src,
                             CloudConstPtr cloud_tgt,
                             pcl::Correspondences &corresps_filtered);


      bool enable_visualization_;
      pcl::visualization::PCLVisualizer::Ptr visualizer_;

      boost::shared_ptr<pcl::registration::CorrespondenceEstimationOrganizedProjection<PointT, PointT> > correspondence_estimation_projection_;
      float correspondence_estimation_projection_distance_threshold_;

       boost::shared_ptr<pcl::registration::CorrespondenceEstimation<PointT, PointT> > correspondence_estimation_closest_point_;
       float correspondence_estimation_closest_point_distance_threshold_;


      boost::shared_ptr<pcl::registration::CorrespondenceRejectorSurfaceNormal> correspondence_rejection_normals_;
      float correspondence_rejection_normal_angle_threshold_;

      // boost::shared_ptr<pcl::registration::CorrespondenceRejectorSampleConsensus<PointT> > correspondence_rejection_sac_;
      // float correspondence_rejection_sac_distance_threshold_;

      int max_num_iterations_projection_;
      // int max_num_iterations_closest_point_;

      int min_num_correspondences_;

      const float sigma_z_min_;

      EIGEN_MAKE_ALIGNED_OPERATOR_NEW
  };
}


